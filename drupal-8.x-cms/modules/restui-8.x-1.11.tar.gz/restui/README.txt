REST UI
=======

This module provides a user interface to manage REST resources.

Installation
============

Place this module at <drupal root>/modules/contrib/ and then install it.
In order to be able to create content, you need the HAL module to be
installed too.

Once the module has been installed, navigate to admin/config/services/rest
(Configuration > Web Services > REST through the administration panel) and configure the available resources.
