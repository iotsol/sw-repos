.. ElastAlert documentation master file, created by
   sphinx-quickstart on Thu Jul 11 15:45:31 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ElastAlert - Easy & Flexible Alerting With Elasticsearch
========================================================

Contents:

.. toctree::
   :maxdepth: 2

   elastalert
   running_elastalert
   ruletypes
   elastalert_status
   recipes/adding_rules
   recipes/adding_alerts
   recipes/writing_filters
   recipes/adding_enhancements

Indices and Tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
